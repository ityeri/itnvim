return {
    "mason-org/mason.nvim",
    lazy = false,
    opts = {}
}
