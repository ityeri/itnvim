return {
    'numToStr/Comment.nvim',
    opts = {
        toggler = {
            line = '<leader>/',
        },
    },
}
